"""Shared utilities for Azure Functions"""

