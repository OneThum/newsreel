"""FastAPI Story API"""

